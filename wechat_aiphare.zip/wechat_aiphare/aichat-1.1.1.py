import json
import os
from itchat.content import *
import random
from multiprocessing import Process
from pandas import DataFrame
import itchat
import pandas as pd
from pyecharts import Pie, Map, Style, Page, Bar
import sys
from urllib.parse import quote
import requests
import re
import time
from time import sleep

def get_response(msg,*image):
    apiUrl = 'http://openapi.tuling123.com/openapi/api/v2'
    date = {
        "reqType":0,
        "perception": {
            "inputText": {
                "text": msg
            },
            "inputImage": {
                "url": image
            },
            "selfInfo": {
                "location": {
                    "city": "广东",
                    "province": "深圳",
                    "street": "民治"
                }
            }
        },
        "userInfo": {
            "apiKey": "038e491b445b4b3596ae1d9a0cc7d47b",
            "userId": "wechat"
        }
    }
    date = json.dumps(date)
    r = requests.post(apiUrl, data=date).json()
    for x in r['results']:
        if x['resultType'] == 'url':
            url = x['values']['url']
        elif x['resultType'] == 'text':
            text = x['values']['text']
        print('我:', x['values']['text'])
    try:
        return text + url
    except UnboundLocalError:
        return text


@itchat.msg_register(TEXT,isFriendChat=True,isGroupChat=False)
def msg_reply(msg):  # 为了保证在图灵Key出现问题的时候仍旧可以回复，这里设置一个默认回复
    defaultReply = '你说的是个啥？我没听清，有本事再说一遍'  # 如果图灵Key出现问题，那么reply将会是None
    print(msg)
    if msg['Text'] == '好友性别分析':
        analysisSex()
        return '好的，性别分析已完成'
    elif msg['Text'] == '好友省份分析':
        analysisProvince()
        return '好友省份分析已准备好了呢'
    elif msg['Text'] == '好友城市分析':
        analysisCity('江西')
        return '城市分析已完成'
    elif re.findall("图片$",msg['Text']):
        # p = Process(target=get_picture,args=(msg['Text'],))
        # p.start()
        # p.join()
        get_picture(msg['Text'])
        send_images(msg['FromUserName'])
        return '发送完成，慢慢欣赏吧！'
    print(msg.User.NickName + ':' + msg['Content'])
    reply = get_response(msg['Text'])  # a or b的意思是，如果a有内容，那么返回a，否则返回b
    return reply or defaultReply

#开启群聊是isGroupChat=True，默认为false#'isAt'是微信的@符号
@itchat.msg_register(TEXT, isFriendChat=False,isGroupChat=True)
def text_reply(msg):
    if msg['isAt']:
        defaultReply='机器人放假回家了...'
        # 如果图灵Key出现问题，那么reply将会是None
    reply = get_response(msg['Text'])
    # a or b的意思是，如果a有内容，那么返回a，否则返回b
    if reply==None:
        reply=defaultReply
    reply="@%s\u2005"%(msg['ActualNickName'])+reply
    print(msg['ActualNickName'],':',msg['Content'])
    return reply

@itchat.msg_register([PICTURE, RECORDING, ATTACHMENT, VIDEO])
def download_files(msg):
    print(msg)
    t = msg['Text'](msg['FileName'])
    print(t)
    return '@%s@%s' % ({'Picture': 'img', 'Video': 'vid'}.get(msg['Type'], 'fil'), msg['FileName'])


@itchat.msg_register(FRIENDS)
def add_friend(msg):

    itchat.add_friend(**msg['Text']) # 该操作会自动将新好友的消息录入，不需要重载通讯录

    itchat.send_msg('Nice to meet you!', msg['RecommendInfo']['UserName'])



def sex_ratio():
    male = female = other = 0
    friends = itchat.get_friends()
    for i in friends[1:]:
        sex = i['Sex']
        if sex == 1:
            male += 1
        elif sex == 2:
            female += 1
        else:
            other += 1
    total = len(friends[1:])
    male_ratio = float(male)/total*100
    female_ratio = float(female)/total*100
    unknown = float(other) / total * 100
    print("男性好友： %.2f%%" % male_ratio + "\n"+"女性好友： %.2f%%" % female_ratio + "\n" +"不明性别好友： %.2f%%" % unknown)

def get_var(var):
    variable = []
    friends = itchat.get_friends()
    for i in friends[1:]:
        value = i[var]
        variable.append(value)
    return variable

#调用函数得到各变量，并把数据存到csv文件中，保存到桌面
def infor_distr():
    NickName = get_var("NickName")
    Sex = get_var('Sex')
    Province = get_var('Province')
    City = get_var('City')
    Signature = get_var('Signature')
    data = {'NickName': NickName, 'Sex': Sex, 'Province': Province,
            'City': City, 'Signature': Signature}
    print(data)
    frame = DataFrame(data)
    frame.to_csv('data.csv', index=True)

def city_distr():
    City = get_var('City')
    print(City)
    dic = dict()
    for i in City:
        Count = str(City.count(i))
        if i == '':
            i = 'other'
        d = {i:Count}
        if i in dic:
            continue
        dic.update(d)
    print(dic)
    for i,v in dic.items():
        print(i, v)
    # frame = DataFrame(data)
    # frame.to_csv('city_count.csv',index=True)


# 根据key值得到对应的信息
def get_key_info(friends_info, key):
    return list(map(lambda friend_info: friend_info.get(key), friends_info))


# 获得所需的微信好友信息
def get_friends_info():
    friends = itchat.get_friends()
    friends_info = dict(
        # 省份
        province=get_key_info(friends, "Province"),
        # 城市
        city=get_key_info(friends, "City"),
        # 昵称
        nickname=get_key_info(friends, "Nickname"),
        # 性别
        sex=get_key_info(friends, "Sex"),
        # 签名
        signature=get_key_info(friends, "Signature"),
        # 备注
        remarkname=get_key_info(friends, "RemarkName"),
        # 用户名拼音全拼
        pyquanpin=get_key_info(friends, "PYQuanPin")
    )
    return friends_info


# 性别分析
def analysisSex():
    friends_info = get_friends_info()
    df = pd.DataFrame(friends_info)
    sex_count = df.groupby(['sex'], as_index=True)['sex'].count()
    temp = dict(zip(list(sex_count.index), list(sex_count)))
    data = {}
    data['保密'] = temp.pop(0)
    data['男'] = temp.pop(1)
    data['女'] = temp.pop(2)
    # 画图
    page = Page()
    attr, value = data.keys(), data.values()
    chart = Pie('微信好友性别比')
    chart.add('', attr, value, center=[50, 50],
              redius=[30, 70], is_label_show=True, legend_orient='horizontal', legend_pos='center',
              legend_top='bottom', is_area_show=True)
    page.add(chart)
    page.render(r'.\templates\analSex.html')


# 省份分析
def analysisProvince():
    friends_info = get_friends_info()
    df = pd.DataFrame(friends_info)
    province_count = df.groupby('province', as_index=True)['province'].count().sort_values()
    temp = list(map(lambda x: x if x != '' else '未知', list(province_count.index)))
    # 画图
    page = Page()
    style = Style(width=1100, height=600)
    style_middle = Style(width=900, height=500)
    attr, value = temp, list(province_count)
    chart1 = Map('好友分布(中国地图)', **style.init_style)
    chart1.add('', attr, value, is_label_show=True, is_visualmap=True, visual_text_color='#000')
    page.add(chart1)
    chart2 = Bar('好友分布柱状图', **style_middle.init_style)
    chart2.add('', attr, value, is_stack=True, is_convert=True,
               label_pos='inside', is_legend_show=True, is_label_show=True)
    page.add(chart2)
    page.render(r'.\templates\analProvince.html')


# 具体省份分析
def analysisCity(province):
    friends_info = get_friends_info()
    df = pd.DataFrame(friends_info)
    temp1 = df.query('province == "%s"' % province)
    city_count = temp1.groupby('city', as_index=True)['city'].count().sort_values()
    attr = list(map(lambda x: '%s市' % x if x != '' else '未知', list(city_count.index)))
    value = list(city_count)
    # 画图
    page = Page()
    style = Style(width=1100, height=600)
    style_middle = Style(width=900, height=500)
    chart1 = Map('%s好友分布' % province, **style.init_style)
    chart1.add('', attr, value, maptype='%s' % province, is_label_show=True,
               is_visualmap=True, visual_text_color='#000')
    page.add(chart1)
    chart2 = Bar('%s好友分布柱状图' % province, **style_middle.init_style)
    chart2.add('', attr, value, is_stack=True, is_convert=True, label_pos='inside', is_label_show=True)
    page.add(chart2)
    page.render(r'.\templates\analCity.html')



#循环获取返回的内容
def getResponse(url):
    headers = {"User-Agent": "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1 Trident/5.0;"}
    r = requests.get(url, headers=headers).text

    pattern1 = re.compile(r'"thumb":"(.*?)","grpcnt".*?', re.S)
    results = re.findall(pattern1, r)
    #print(results)
    loadImage(results)


#下载图片并保存在本地
def loadImage(results):
    a = 1
    while a < len(results[:15]):
        for result in results:
            # print(result)
            resul = result.replace("\\", "")
            print(resul)
            fileName =  "{}".format(resul[-9:-4]) + ".jpg"
            with open("./static/imge/" + fileName, "wb") as f:
                headers = {"User-Agent": "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1 Trident/5.0;"}
                sleep(0.2)
                image = requests.get(resul, headers=headers).content
                f.write(image)
                print(fileName)
            a += 1


#main函数控制器
def main(url):
    getResponse(url)


def get_picture(name):
    i = 1
    sn = 53
    while i < 2:
        if name == "停止传输图片":
            sys.exit("感谢使用!")
        nameHttp = quote(name)
        url = 'https://m.image.so.com/j?q={}&src=srp&pn=30&sn={}&kn=23&gn=0&cn=0'.format(nameHttp, sn)
        main(url)
        print("sn=", sn)
        print("当前搜索次数为:", i, "次")
        sn += 30
        i += 1


# send_image(fileDir, toUserName=None, mediaId=None)
def send_images(toUsername):
    path = 'D:/Python Project/wechat_aiphare/static/imge/'
    filename = os.listdir(path)
    print(filename)
    for x in filename:
        print(x)
        imgpath = path + x
        itchat.send_image(imgpath,toUsername)
        print(toUsername)
        # os.remove(imgpath)



if __name__ == '__main__':
    itchat.auto_login(hotReload=True)
    itchat.run()




