#!/usr/bin/env python
#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#                 _ooOoo_
#                o8888888o
#                88" . "88
#                (| -_- |)
#                O\  =  /O
#             ____/`---'\____
#           .'  \\|     |//  `.
#          /  \\|||  :  |||//  \
#         /  _||||| -:- |||||-  \
#         |   | \\\  -  /// |   |
#         | \_|  ''\---/''  |   |
#         \  .-\__  `-`  ___/-. /
#       ___`. .'  /--.--\  `. . __
#    ."" '<  `.___\_<|>_/___.'  >'"".
#   | | :  `- \`.;`\ _ /`;.`/ - ` : | |
#   \  \ `-.   \_ __\ /__ _/   .-` /  /
#====`-.____`-.___\_____/___.-`____.-'======
#                 `=---='
#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#         Buddha bless   Never bug
#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#       江城子 . 程序员之歌                   
#                                           
#      十年生死两茫茫，写程序，到天亮。        
#          千行代码，Bug何处藏。              
#      纵使上线又怎样，朝令改，夕断肠。         
#                                               
#      领导每天新想法，天天改，日日忙。
#           相顾无言，惟有泪千行。
#      每晚灯火阑珊处，夜难寐，加班狂。
#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# 开发环境：Windows10 + pycharm + python3.7
# 时间：2018年10月14日
# 作者：aiphare
# 声明：如需使用请注明出处，并更换源代码中
#   userInfo中的'apikey'，否则可能无法正常运行，
#   具体请自行百度图灵官网
#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
import json
import os
from itchat.content import *
import random
from multiprocessing import Process
import itchat
import pandas as pd
from pyecharts import Pie, Map, Style, Page, Bar
import sys
from urllib.parse import quote
import requests
import re
import time
from time import sleep

def get_response(msg):
    apiUrl = 'http://openapi.tuling123.com/openapi/api/v2'
    date = {
        "reqType":0,
        "perception": {
            "inputText": {
                "text": msg
            },
            "inputImage": {
                "url": 'image'
            },
            "selfInfo": {
                "location": {
                    "city": "广东",
                    "province": "深圳",
                    "street": "民治"
                }
            }
        },
        "userInfo": {
            "apiKey": "038e491b445b4b3596ae1d9a0cc7d47b",
            "userId": "wechat"
        }
    }
    date = json.dumps(date)
    r = requests.post(apiUrl, data = date).json()
    for x in r['results']:
        if x['resultType'] == 'url':
            url = x['values']['url']
        elif x['resultType'] == 'text':
            text = x['values']['text']
        print('我:', x['values']['text'])
    try:
        return text + url
    except UnboundLocalError:
        return text

@itchat.msg_register([TEXT, PICTURE, FRIENDS, CARD, MAP, SHARING, RECORDING, ATTACHMENT, VIDEO],
                     isFriendChat = True, isGroupChat = True, isMpChat = True)
def handle_receive_msg(msg):
    print(msg)
    global notchat_list
    global face_bug
    msg_time_rec = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())   #接受消息的时间
    if msg.FromUserName[0:2] == '@@':
        # 群聊获取好友
        msg_from = itchat.search_friends(userName = msg['ActualUserName']).NickName
    else:
        # 独聊获取好友
        # 易于保存，报错就pass
        try:
            msg_from = itchat.search_friends(userName = msg.FromUserName).NickName # 在好友列表中查询发送信息的好友昵称
        except:
            pass
    msg_time = msg['CreateTime']    #信息发送的时间
    msg_id = msg['MsgId']    #每条信息的id
    msg_content = None      #储存信息的内容
    msg_share_url = None    #储存分享的链接，比如分享的文章和音乐
    print(msg['Type'])
    print(msg['MsgId'])
    if msg['Type'] == 'Text' or msg['Type'] == 'Friends':     #如果发送的消息是文本或者好友推荐
        msg_content = msg['Text']
        print(msg_from, ':', msg_content)
        if msg['Type'] == 'Text':
            if msg['Text'] == '退下':
                itchat.send_msg("不好意思，打扰了，小的退下了，如果有需要你可以对我说:'美丽可爱大方有才华的小ai快来',我随叫随到呢",
                                msg.FromUserName)
                notchat_list.append(msg.FromUserName)
            elif msg['Text'] == '美丽可爱大方又温柔的小ai快来':
                if msg.FromUserName in notchat_list:
                    itchat.send_msg('来啦来啦，是不是想我了？', msg.FromUserName)
                    notchat_list.remove(msg.FromUserName)
                else:
                    t = get_response(msg['Text'])
                    itchat.send_msg(t, msg.FromUserName)
            else:
                if msg.FromUserName not in notchat_list:
                    # 判断是否是自己本人
                    if msg.FromUserName == friends[0:1][0]['UserName']:
                        if msg['Text'] == '好友性别分析':
                            analysisSex()
                            print('好友性别分析已完成')
                            itchat.send_msg('小可爱ai：好的，性别分析已完成', 'filehelper')
                        elif msg['Text'] == '全国好友分析':
                            analysisCountry()
                            itchat.send_msg('小可爱ai：全国好友各省份分析已准备好了呢', 'filehelper')
                        elif re.findall(r'.*省好友分析$', msg['Text']):
                            provincce = msg['Text'][:-5]
                            analysisProvince(provincce)
                            itchat.send_msg('小可爱ai：' + provincce + '省好友分析已完成', 'filehelper')
                        elif re.findall("^给我发点.*图片$", msg['Text']):
                            itchat.send_msg('你需要的图片正在准备中....', msg.FromUserName)
                            ms = msg['Text'][4:]
                            print(ms)
                            p = Process(target=get_picture, args=(ms,))
                            p.start()
                            p.join()
                            send_images('filehelper')
                        elif re.findall(r'^今天.*天气怎么样$', msg['Text']):
                            if len(msg['Text']) == 9:
                                city = msg['Text'][2:4]
                            elif len(msg['Text']) == 10:
                                city = msg['Text'][2:5]
                            elif len(msg['Text']) == 11:
                                city = msg['Text'][2:6]
                            weather_text = getWea_request(city)
                            print('wether_text:', weather_text)
                            itchat.send_msg(weather_text, 'filehelper')
                        elif msg['Text'] == '退出机器人模式':
                            itchat.logout()
                        else:
                            t = get_response(msg['Text'])
                            print(t)
                            itchat.send_msg('小可爱ai：' + t, 'filehelper')

                    elif re.findall("^给我发点.*图片$", msg['Text']):
                        itchat.send_msg('你需要的图片正在准备中....', msg.FromUserName)
                        ms = msg['Text'][4:]
                        print(ms)
                        p = Process(target = get_picture, args=(ms, ))
                        p.start()
                        p.join()
                        send_images(msg.FromUserName)
                    elif re.findall(r'^今天.*天气怎么样$', msg['Text']):
                        if len(msg['Text']) == 9:
                            city = msg['Text'][2:4]
                        elif len(msg['Text']) == 10:
                            city = msg['Text'][2:5]
                        elif len(msg['Text']) == 11:
                            city = msg['Text'][2:6]
                        weather_text = getWea_request(city)
                        print('wether_text:', weather_text)
                        itchat.send_msg(weather_text, msg.FromUserName)
                    elif msg['Text'] == '掷骰子':
                        itchat.send_image(r'.\static\face_picture\zhisaizi.gif', msg.FromUserName)
                    else:
                        t = get_response(msg['Text'])
                        itchat.send_msg(t, msg.FromUserName)


    #如果发送的消息是附件、视屏、图片、语音
    elif msg['Type'] == "Attachment" or \
            msg['Type'] == "Video" or \
            msg['Type'] == 'Picture' or \
            msg['Type'] == 'Recording':
        msg_content = msg['FileName']    #内容就是他们的文件名
        msg['Text'](str(msg_content))    #下载文件
        # print msg_content
        if msg['Type'] == 'Picture':
            if msg.FromUserName not in notchat_list:
                if msg.FromUserName == friends[0:1][0]['UserName']:
                    itchat.send_msg('小可爱ai：你发给我的图片，我已收好放心好了', 'filehelper')
                else:
                    L = ['a.jpg', 'b.jpg', 'c.jpg', 'd.jpg', 'e.jpg', 'f.jpg', 'g.png', 'h.jpg', 'i.jpg', 'j.jpg', 'k.jpg',
                         'l.jpg', 'm.jpg', 'n.jpg', 'o.jpg', 'p.jpg', 'q.jpg', 'r.jpg', 's.jpg', 't.jpg', 'u.jpg', 'v.jpg',
                         'w.jpg', 'x.jpg', 'y.jpg', 'z.jpg', '1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg', '6.jpg', '7.jpg',
                         '8.jpg', '9.jpg', '10.jpg', '11.jpg', '12.jpg', '13.jpg', '14.jpg', '15.jpg', '16.jpg', '17.jpg',
                         '18.jpg', '19.jpg', '20.jpg', '21.jpg', '22.jpg', '23.jpg', '24.jpg', '25.jpg', '26.jpg', '27.jpg',
                         '28.jpg', '29.jpg', '30.jpg', '31.gif', '32.gif', '33.png', '34.gif' ]
                    p = random.choice(L)
                    paddr = '.\static\\face_picture\\' + p
                    itchat.send_image(paddr, toUserName=msg.FromUserName)
                    print("Send Picture Success!")
    elif msg['Type'] == 'Card':    #如果消息是推荐的名片
        msg_content = msg['RecommendInfo']['NickName'] + '的名片'    #内容就是推荐人的昵称和性别
        if msg.FromUserName not in notchat_list:
            if msg.FromUserName == friends[0:1][0]['UserName']:
                itchat.send_msg('小可爱ai：你给我推荐的名片，我已收好了呢，谢谢你啊', 'filehelper')
            else:
                if msg['RecommendInfo']['Sex'] == 1:
                    msg_content += '性别为男'
                else:
                    msg_content += '性别为女'
                print(msg_content)
    elif msg['Type'] == 'Map':    #如果消息为分享的位置信息
        if msg.FromUserName == friends[0:1][0]['UserName']:
            itchat.send_msg('小可爱ai：原来你在这里啊，我在梦里找了你好久啊', 'filehelper')
        else:
            x, y, location = re.search(
                "<location x=\"(.*?)\" y=\"(.*?)\".*label=\"(.*?)\".*", msg['OriContent']).group(1, 2, 3)
            if location is None:
                msg_content = r"纬度->" + x.__str__() + " 经度->" + y.__str__()     #内容为详细的地址
            else:
                msg_content = r"" + location
    elif msg['Type'] == 'Sharing':     #如果消息为分享的音乐或者文章，详细的内容为文章的标题或者是分享的名字
        if msg.FromUserName == friends[0:1][0]['UserName']:
            itchat.send_msg('小可爱ai：你给我的分享，我会记在心里', 'filehelper')
        else:
            msg_content = msg['Text']
            msg_share_url = msg['Url']       #记录分享的url
            print(msg_share_url)

    face_bug=msg_content
    #将信息存储在字典中，每一个msg_id对应一条信息
    #易于保存，报错就pass
    try:
        msg_information.update(
            {
                msg_id: {
                    "msg_from": msg_from, "msg_time": msg_time, "msg_time_rec": msg_time_rec,
                    "msg_type": msg["Type"],
                    "msg_content": msg_content, "msg_share_url": msg_share_url
                }
            }
        )
    except:
        pass


##这个是用于监听是否有消息撤回
@itchat.msg_register(NOTE, isFriendChat=True, isGroupChat=True, isMpChat=True)
def information(msg):
    #这里如果这里的msg['Content']中包含消息撤回和id，就执行下面的语句
    if '撤回了一条消息' in msg['Content']:
        old_msg_id = re.search("\<msgid\>(.*?)\<\/msgid\>", msg['Content']).group(1)   #在返回的content查找撤回的消息的id
        old_msg = msg_information.get(old_msg_id)    #得到消息
        print(old_msg)
        if len(old_msg_id)<11:  #如果发送的是表情包
            itchat.send_file(face_bug, toUserName='filehelper')
        else:  #发送撤回的提示给文件助手
            msg_body = "告诉你一个秘密~" + "\n" \
                       + old_msg.get('msg_from') + " 撤回了 " + old_msg.get("msg_type") + " 消息" + "\n" \
                       + old_msg.get('msg_time_rec') + "\n" \
                       + "撤回了什么 ⇣" + "\n" \
                       + r"" + old_msg.get('msg_content')
            #如果是分享的文件被撤回了，那么就将分享的url加在msg_body中发送给文件助手
            if old_msg['msg_type'] == "Sharing":
                msg_body += "\n就是这个链接➣ " + old_msg.get('msg_share_url')

            # 将撤回消息发送到文件助手
            itchat.send_msg(msg_body, toUserName='filehelper')
            # 有文件的话也要将文件发送回去
            if old_msg["msg_type"] == "Picture" \
                    or old_msg["msg_type"] == "Recording" \
                    or old_msg["msg_type"] == "Video" \
                    or old_msg["msg_type"] == "Attachment":
                file = '@fil@%s' % (old_msg['msg_content'])
                itchat.send(msg=file, toUserName='filehelper')
                os.remove(old_msg['msg_content'])
            # 删除字典旧消息
            msg_information.pop(old_msg_id)

# 根据key值得到对应的信息
def get_key_info(friends_info, key):
    return list(map(lambda friend_info: friend_info.get(key), friends_info))

# 获得所需的微信好友信息
def get_friends_info():
    friends = itchat.get_friends()
    friends_info = dict(
        # 省份
        province=get_key_info(friends, "Province"),
        # 城市
        city=get_key_info(friends, "City"),
        # 昵称
        nickname=get_key_info(friends, "Nickname"),
        # 性别
        sex=get_key_info(friends, "Sex"),
        # 签名
        signature=get_key_info(friends, "Signature"),
        # 备注
        remarkname=get_key_info(friends, "RemarkName"),
        # 用户名拼音全拼
        pyquanpin=get_key_info(friends, "PYQuanPin")
    )
    return friends_info


# 性别分析
def analysisSex():
    friends_info = get_friends_info()
    df = pd.DataFrame(friends_info)
    sex_count = df.groupby(['sex'], as_index=True)['sex'].count()
    temp = dict(zip(list(sex_count.index), list(sex_count)))
    data = {}
    data['保密'] = temp.pop(0)
    data['男'] = temp.pop(1)
    data['女'] = temp.pop(2)
    # 画图
    page = Page()
    attr, value = data.keys(), data.values()
    chart = Pie('微信好友性别比')
    chart.add('', attr, value, center=[50, 50],
              redius=[30, 70], is_label_show=True, legend_orient='horizontal', legend_pos='center',
              legend_top='bottom', is_area_show=True)
    page.add(chart)
    page.render(r'.\templates\analSex.html')


# 全国各省份好友分布分析
def analysisCountry():
    friends_info = get_friends_info()
    df = pd.DataFrame(friends_info)
    province_count = df.groupby('province', as_index=True)['province'].count().sort_values()
    temp = list(map(lambda x: x if x != '' else '未知', list(province_count.index)))
    # 画图
    page = Page()
    style = Style(width=1100, height=600)
    style_middle = Style(width=900, height=500)
    attr, value = temp, list(province_count)
    chart1 = Map('好友分布(中国地图)', **style.init_style)
    chart1.add('', attr, value, is_label_show=True, is_visualmap=True, visual_text_color='#000')
    page.add(chart1)
    chart2 = Bar('好友分布柱状图', **style_middle.init_style)
    chart2.add('', attr, value, is_stack=True, is_convert=True,
               label_pos='inside', is_legend_show=True, is_label_show=True)
    page.add(chart2)
    page.render(r'.\templates\analcountry.html')


# 具体省份各城市好友分布分析
def analysisProvince(province):
    friends_info = get_friends_info()
    df = pd.DataFrame(friends_info)
    temp1 = df.query('province == "%s"' % province)
    city_count = temp1.groupby('city', as_index=True)['city'].count().sort_values()
    attr = list(map(lambda x: '%s市' % x if x != '' else '未知', list(city_count.index)))
    value = list(city_count)
    # 画图
    page = Page()
    style = Style(width=1100, height=600)
    style_middle = Style(width=900, height=500)
    chart1 = Map('%s好友分布' % province, **style.init_style)
    chart1.add('', attr, value, maptype='%s' % province, is_label_show=True,
               is_visualmap=True, visual_text_color='#000')
    page.add(chart1)
    chart2 = Bar('%s好友分布柱状图' % province, **style_middle.init_style)
    chart2.add('', attr, value, is_stack=True, is_convert=True, label_pos='inside', is_label_show=True)
    page.add(chart2)
    page.render(r'.\templates\analprovince.html')



#循环获取返回的内容
def getResponse(url):
    headers = {"User-Agent": "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1 Trident/5.0;"}
    r = requests.get(url, headers=headers).text

    pattern1 = re.compile(r'"thumb":"(.*?)","grpcnt".*?', re.S)
    results = re.findall(pattern1, r)
    #print(results)
    loadImage(results)


#下载图片并保存在本地
def loadImage(results):
    a = 1
    while a < len(results[:15]):
        for result in results:
            # print(result)
            resul = result.replace("\\", "")
            print(resul)
            fileName =  "{}".format(resul[-9:-4]) + ".jpg"
            with open("./static/imge/" + fileName, "wb") as f:
                headers = {"User-Agent": "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1 Trident/5.0;"}
                sleep(0.2)
                image = requests.get(resul, headers=headers).content
                f.write(image)
                print(fileName)
            a += 1


#main函数控制器
def main(url):
    getResponse(url)


def get_picture(name):
    i = 1
    sn = 53
    while i < 2:
        if name == "停止传输图片":
            sys.exit("感谢使用!")
        nameHttp = quote(name)
        url = 'https://m.image.so.com/j?q={}&src=srp&pn=30&sn={}&kn=23&gn=0&cn=0'.format(nameHttp, sn)
        main(url)
        print("sn=", sn)
        print("当前搜索次数为:", i, "次")
        sn += 30
        i += 1


# send_image(fileDir, toUserName=None, mediaId=None)
def send_images(toUsername):
    path = 'D:/Python Project/wechat_aiphare/static/imge/'
    filename = os.listdir(path)
    print(filename)
    for x in filename:
        print(x)
        imgpath = path + x
        itchat.send_image(imgpath,toUsername)
        print(toUsername)
        os.remove(imgpath)

def getWea_request(city):
    apiUrl = 'http://v.juhe.cn/weather/index'
    date = {
        'format':'2',
        "cityname":city,
        "key":"852d3e78691fee99e36ac4fdae437ce4",
    }
    # api = 'http://v.juhe.cn/weather/index?format=2&cityname=%E8%8B%8F%E5%B7%9E&key=852d3e78691fee99e36ac4fdae437ce4'
    r = requests.get(apiUrl, date).json()
    if r['resultcode'] == '200':
        print(r)
        temp = r['result']['sk']['temp']
        print('实时温度', temp)
        wind_direction = r['result']['sk']['wind_direction']
        print('风向:', wind_direction)
        wind_strength = r['result']['sk']['wind_strength']
        print('风力强度：', wind_strength)
        humidity = r['result']['sk']['humidity']
        print('湿度：', humidity)
        tim = r['result']['sk']['time']
        print('当前时间:', tim)
        temperature = r['result']['today']['temperature']
        print('今日温度：', temperature)
        weather = r['result']['today']['weather']
        print('天气：', weather)
        wind = r['result']['today']['wind']
        print(wind)
        week = r['result']['today']['week']
        print(week)
        cit = r['result']['today']['city']
        print(cit)
        date_y = r['result']['today']['date_y']
        print(date_y)
        dressing_index = r['result']['today']['dressing_index']
        print(dressing_index)
        dressing_advice = r['result']['today']['dressing_advice']
        print(dressing_advice)
        uv_index = r['result']['today']['uv_index']
        print(uv_index)
        weather_text = '今天' + date_y + ' ' + week + ',' + ' 所在城市 ' + cit + ',' + ' 天气 ' + weather + ',' + ' 温度 ' +\
                       temperature +',' + wind + ',' +dressing_advice
        weather_text += '实时天气：当前时间 ' + tim + ',温度 ' + temp + '°C,' + '风向 ' + wind_direction + ',风力强度 ' + \
                       wind_strength + ',湿度 ' + humidity
        return weather_text
    else:
        return '没有你要查询城市的天气，或者请重新输入想要查询天气的城市，按照“今天XX天气怎么样”进行再次查询'


if __name__ == '__main__':
    itchat.auto_login(hotReload=True)
    friends = itchat.get_friends()
    msg_information = {}
    face_bug = None  # 针对表情包的内容
    notchat_list = []
    itchat.run()